# Documentation

This directory contains all documentation related to the EduManage project.

-   Architecture Decisions
-   API Specifications
-   Deployment Guides
