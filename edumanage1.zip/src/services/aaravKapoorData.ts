import { StudentMark } from '../types/index';

export const aaravKapoorMarks: StudentMark[] = [];
