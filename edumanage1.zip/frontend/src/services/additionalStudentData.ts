import { StudentMark } from '../types/index';

// Data for ESHA PATEL (KCSE202005) - Cleared
export const eshaPatelMarks: StudentMark[] = [];

// Data for DEEPAK KUMAR (KCSE202004) - Cleared
export const deepakKumarMarks: StudentMark[] = [];

// Data for BHUKYA DHARMA (KCSE202006) - Cleared
export const bhukyaDharmaMarks: StudentMark[] = [];
